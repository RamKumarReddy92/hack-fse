package com.cognizant.shopping.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.shopping.model.Order;

@Repository
public interface OrderRepository extends MongoRepository<Order,String>{

	@Query("{'customer':{'customerId':?0}}")
	public List<Order> findCustomerOrders(String loginId);
	
	
}
