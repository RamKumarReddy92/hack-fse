package com.cognizant.shopping.controller;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.shopping.model.Admin;
import com.cognizant.shopping.model.ApiErrorResponse;
import com.cognizant.shopping.model.ApiResponse;
import com.cognizant.shopping.model.Customer;
import com.cognizant.shopping.model.LoginCredentials;
import com.cognizant.shopping.model.User;
import com.cognizant.shopping.repository.AdminRepository;
import com.cognizant.shopping.service.AuthenticationService;
import com.cognizant.shopping.service.CustomerService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1.0/shopping")
public class AuthenticationController {

	@Autowired
	private AdminRepository adminRepository;

	@PostMapping("/admins/create")
	public ResponseEntity<ApiResponse> createAdmin(@RequestBody Admin admin)
	{
		this.adminRepository.save(admin);
		ApiResponse response = new  ApiResponse("Admin created successfully");
		return ResponseEntity.status(HttpStatus.CREATED).body(response);
	}
	
	
	
}
