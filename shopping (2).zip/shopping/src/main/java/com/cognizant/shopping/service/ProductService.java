package com.cognizant.shopping.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.shopping.model.Customer;
import com.cognizant.shopping.model.Product;
import com.cognizant.shopping.repository.CustomerRepository;
import com.cognizant.shopping.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;
	
	private CustomerRepository customerRespository;
	
	public List<Product> getAllProducts()
	{
		return this.productRepository.findAll();
	}
	
	public Optional<Product> getProduct(String productId)
	{
		return this.productRepository.findById(productId);
	}
	public String addProduct(Product product)
	{
		Product createdProduct = this.productRepository.save(product);
		return createdProduct.getProductId();
		
	}
	public List<Product> searchProducts(String productName)
	{
		return this.productRepository.findByProductNameContainingIgnoreCase(productName);	
	}
	public void deleteProduct(String productId)
	{
		this.productRepository.deleteById(productId);
	}
	public void updateProductStatus(String productId)
	{
		Product product = this.productRepository.findByProductId(productId);
		product.setProductStatus("OUT OF STOCK");
		this.productRepository.save(product);
	}
	
	
}
