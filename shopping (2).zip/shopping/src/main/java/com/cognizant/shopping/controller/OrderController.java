package com.cognizant.shopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.shopping.model.ApiResponse;
import com.cognizant.shopping.model.Order;
import com.cognizant.shopping.service.OrderService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1.0/shopping/orders")
public class OrderController {
	
	@Autowired
	private OrderService orderService;
	
	@PostMapping("/create")
	public ResponseEntity<ApiResponse> placeOrder(@RequestBody Order order)
	{
		String placedOrderId  = this.orderService.createOrder(order);
		ApiResponse response = new ApiResponse("Order created successfully with order id"+placedOrderId);
		return new ResponseEntity<>(response,HttpStatus.CREATED);
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<Order>> getAllOrders()
	{
		List<Order> orders =  this.orderService.getAllOrders();
		return new ResponseEntity<>(orders,HttpStatus.OK);
	}
	
	@GetMapping("/{loginId}/orders")
	public ResponseEntity<List<Order>> getCustomerOrders(@PathVariable("loginId") String loginId)
	{
		List<Order> orders = this.orderService.getCustomerOrders(loginId);
		return new ResponseEntity<>(orders,HttpStatus.OK);
	}

}
