package com.cognizant.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.shopping.model.Order;
import com.cognizant.shopping.repository.OrderRepository;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepository;
	
	public List<Order> getAllOrders()
	{
		return this.orderRepository.findAll();
	}
	
	public String createOrder(Order order)
	{
		Order placedOrder = this.orderRepository.save(order);
		return placedOrder.getOrderId();
	}
	
	public List<Order> getCustomerOrders(String loginId)
	{
		return this.orderRepository.findCustomerOrders(loginId);
	}
	
}
