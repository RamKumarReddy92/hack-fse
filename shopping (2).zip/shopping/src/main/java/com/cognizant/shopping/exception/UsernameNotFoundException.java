package com.cognizant.shopping.exception;

public class UsernameNotFoundException extends RuntimeException {

	public UsernameNotFoundException(String message)
	{
		super(message);
	}
}
