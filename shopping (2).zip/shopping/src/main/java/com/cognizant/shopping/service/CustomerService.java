package com.cognizant.shopping.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.shopping.exception.IncorrectPasswordException;
import com.cognizant.shopping.exception.UserAlreadyExistsException;
import com.cognizant.shopping.exception.UsernameNotFoundException;
import com.cognizant.shopping.model.Admin;
import com.cognizant.shopping.model.Customer;
import com.cognizant.shopping.model.LoginCredentials;
import com.cognizant.shopping.model.Product;
import com.cognizant.shopping.model.User;
import com.cognizant.shopping.repository.AdminRepository;
import com.cognizant.shopping.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
	private ProductService productService;
	
	public void addCustomer(User user)
	{
		Customer customer = new Customer();
		BeanUtils.copyProperties(user, customer);
		
		Customer c = this.customerRepository.findByLoginIdOrEmail(customer.getLoginId(),customer.getEmail());
		
		if(c!=null)
			throw new UserAlreadyExistsException("Either login id or email are already exists!");
		
		this.customerRepository.save(customer);
	}
	
	public boolean validateCredentials(LoginCredentials loginCredentials)
	{
		Admin admin = this.adminRepository.findByLoginId(loginCredentials.getLoginId());
		Customer customer = this.customerRepository.findByLoginId(loginCredentials.getLoginId());
		if(customer == null && admin == null)
			throw new UsernameNotFoundException("Login Id does not exists!!");
		if(admin!=null && !admin.getPassword().equals(loginCredentials.getPassword()))
		{
			throw new IncorrectPasswordException("Password is not correct");
		}
		if(customer!=null && !customer.getPassword().equals(loginCredentials.getPassword()))
			throw new IncorrectPasswordException("Password is not correct");
		
		return true;
	}
	
	public void resetPassword(String loginId,String password)
	{
		Customer customer = this.customerRepository.findByLoginId(loginId);
		if(customer == null)
			throw new UsernameNotFoundException("Login Id does not exists!!");
		
		customer.setPassword(password);
		this.customerRepository.save(customer);
		
	}
	
	public List<Customer> getAllCustomers()
	{
		return this.customerRepository.findAll();
	}
	
	public void addToCart(String loginId,String productId)
	{
		Customer customer = this.customerRepository.findByLoginId(loginId);
		if(customer.getCart() == null)
		{
			customer.setCart(new ArrayList<>());
		}
		customer.getCart().add(productId);
		this.customerRepository.save(customer);
	}
	
	public void deleteCartItem(String loginId,String productId)
	{
		Customer customer = this.customerRepository.findByLoginId(loginId);
		if(customer.getCart() == null)
		{
			customer.setCart(new ArrayList<>());
		}
		customer.getCart().remove(productId);
		this.customerRepository.save(customer);
	}
	
	public List<Product> getCartItems(String loginId)
	{
		Customer customer = this.customerRepository.findByLoginId(loginId);
		List<String> productIds = customer.getCart();
		
		List<Product> products = productIds.stream()
									.map(id->this.productService.getProduct(id).get())
									.collect(Collectors.toList());
		return products;
	}
	
	public Customer getCustomer(String loginId)
	{
		return this.customerRepository.findByLoginId(loginId);
	}
	
	
}
