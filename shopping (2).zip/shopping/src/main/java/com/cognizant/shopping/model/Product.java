package com.cognizant.shopping.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Document(collection = "products")
public class Product {
	
	@Id
	private String productId;
	private String productName;
	private String productDescription;
	private String features;
	private String productStatus;
	private int quantity;
	private int cost;

}
