package com.cognizant.shopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.shopping.model.ApiResponse;
import com.cognizant.shopping.model.Product;
import com.cognizant.shopping.service.ProductService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1.0/shopping/products")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	
	@GetMapping("")
	public ResponseEntity<List<Product>> getAllProducts()
	{
		List<Product> products = this.productService.getAllProducts();
		return new ResponseEntity<>(products,HttpStatus.OK);
	}
	
	@PostMapping("/add")
	public ResponseEntity<ApiResponse> addProduct(@RequestBody Product product)
	{
		String productId = this.productService.addProduct(product);
		ApiResponse response = new ApiResponse("Created Successfully with product id "+productId);
		return new ResponseEntity<>(response,HttpStatus.CREATED);
	}
	
	@GetMapping("/search/{productName}")
	public ResponseEntity<List<Product>> searchProducts(@PathVariable("productName") String productName)
	{
		List<Product> products =  this.productService.searchProducts(productName);
		return new ResponseEntity<>(products,HttpStatus.OK);
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<ApiResponse> updateProductStatus(@PathVariable("id") String productId)
	{
		this.productService.updateProductStatus(productId);
		ApiResponse response = new ApiResponse("Status Updated Successfully");
		return new ResponseEntity<>(response,HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<ApiResponse> addProduct(@PathVariable("id") String productId)
	{
		this.productService.deleteProduct(productId);
		ApiResponse response = new ApiResponse("Deleted Successfully");
		return new ResponseEntity<>(response,HttpStatus.OK);
	}
	
	

}
