export interface Customer 
{
  firstName : string;
  lastName : string;
  email : string;
  loginId : string;
  password: string;
  contactNumber : string;
}