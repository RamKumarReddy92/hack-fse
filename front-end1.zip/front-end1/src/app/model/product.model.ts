export interface Product{
    productId: string;
    productName : string;
    productDescription : string;
    features : string;
    productStatus : string;
    quantity : number;
    cost : number;
  }