import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from '../model/customer.model';
import { AuthService } from '../services/auth.service';
import { CustomerService } from '../services/customer.service';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private authService : AuthService,
    private router : Router,private customerService : CustomerService) { }

  customer : Customer = {} as Customer;
  // { firstName : "ram",
  //                         lastName:"kumar",
  //                         contactNumber:"4329573425",
  //                         email:"ram@gmail.com",
  //                         loginId:"ram123",
  //                         password:"ram123"}

  match : boolean = true;
  updated : boolean = false;
  reset : boolean = false;
  password : FormControl = new FormControl("");
  confirmPassword : FormControl = new FormControl("");
  ngOnInit(): void {
    this.customerService.findCustomer().subscribe(customer =>{
      this.customer = customer;   })
  }

  logout()
  {
    this.authService.logout();
    this.router.navigate(["/login"]);
  }
  resetForm()
  {
    this.reset = !this.reset;
    this.match = true;
    this.updated = false;
    this.confirmPassword.setValue("");
    this.password.setValue("");

  }
  resetPassword()
  {
    this.match = false;
    this.updated = false;
     if(this.password.value !== this.confirmPassword.value)
     {
       this.match = false;
       return;
     }
     else
     {
       this.updated = true;
       this.match = true;
     }
  }

}


