import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MaterialModule } from './material/material.module';
import { CustomerRegisterComponent } from './customer-register/customer-register.component';
import { ProductRegisterComponent } from './product-register/product-register.component';
import { ProfileComponent } from './profile/profile.component';
import { LoginComponent } from './login/login.component';
import { OrdersComponent } from './orders/orders.component';
import { CartComponent } from './cart/cart.component';
import { ProductsComponent , CartAddedDialog} from './products/products.component'
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpCustomInterceptor } from './http.interceptor';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { AdminComponent,ProductStatusUpdateDialog } from './admin/admin.component';

@NgModule({
  declarations: [
    AppComponent,
    CustomerRegisterComponent,
    ProductRegisterComponent,
    ProfileComponent,
    LoginComponent,
    OrdersComponent,
    CartComponent,
    ProductsComponent,
    CartAddedDialog,
    AdminComponent,
    ProductStatusUpdateDialog
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    {
      provide:HTTP_INTERCEPTORS,
      useClass : HttpCustomInterceptor,
      multi : true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
