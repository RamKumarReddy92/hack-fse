import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { baseUrl } from 'src/environments/environment';
import { Customer } from '../model/customer.model';
import { Product } from '../model/product.model';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http : HttpClient) { }

  resetPassword(newPassword : string)
  {
    this.http.post(baseUrl+localStorage.getItem("loginId")+"/forgot",newPassword);
  }

  registerCustomer(customer : Customer)
  {
    this.http.post(baseUrl+"/register",customer);
  }

  findCustomer()
  {
    return this.http.get<Customer>(baseUrl+"/customers/"+localStorage.getItem("loginId"));
  }

  addToCart(productId : string)
  {
    let loginId = localStorage.getItem("loginId");
    return this.http.post(baseUrl+"/customers/"+loginId+"/cart/"+productId,"");
  }

  getCartItems()
  {
    let loginId = localStorage.getItem("loginId");
    return this.http.get<Product[]>(baseUrl+"/customers/"+loginId+"/cart");
  }

  deleteCartItem(productId : string)
  {
    let loginId = localStorage.getItem("loginId");
    return this.http.delete(baseUrl+"/customers/"+loginId+"/delete/cart/"+productId);
  }
  

}
