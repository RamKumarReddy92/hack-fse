import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { baseUrl } from 'src/environments/environment';
import { Product } from '../model/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

  statusUpdate$ : Subject<string> = new Subject();

  getAllProducts()
  {
    return this.http.get<Product[]>(baseUrl+"/products");
  }

  addProduct (product:Product)
  {
    return this.http.post(baseUrl+"/products/add",product);
  }

  searchProducts(productName : string)
  {
    return this.http.get<Product[]>(baseUrl+"/products/search/"+productName);
  }

  updateProductStatus(productId :string,status : string)
  {
    return this.http.put(baseUrl+"/products/update/"+productId,status);
  }
  deleteProduct(productId : string)
  {
    return this.http.delete(baseUrl+"/products/delete/"+productId);
  }
}
