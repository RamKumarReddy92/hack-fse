import { Time } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HammerGestureConfig } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import {baseUrl} from "../../environments/environment"

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http:HttpClient,private router : Router) { }

  statusBar$ : Subject<boolean> = new Subject();
  loggedIn$ : Subject<boolean> = new Subject();
  register(customer: Customer)
  {
    this.http.post(baseUrl + "/customers/register",customer);
    this.router.navigate(["/login"]);
  }

  login(user : User)
  {
    this.http.post<Response>(baseUrl+"/customers/login",user).subscribe(response=>{
        localStorage.setItem("token",response.message);
        localStorage.setItem("loginId",user.loginId);
        this.loggedIn$.next(true);
        this.router.navigate(["/products"]);
    },
    error=>{this.loggedIn$.next(false)});
  }

  logout()
  {
    localStorage.clear();
    this.loggedIn$.next(false);
    this.router.navigate(["/login"]);
  }
  loggedIn()
  {
    return !!localStorage.getItem("token");
  }
}

interface Customer {
  firstName : string;
  lastName : string;
  email : string;
  loginId :string;
  contactNumber : string;
  password : string;
}

interface User 
{
  loginId : string;
  password : string;
}

interface Response
{
  timeStamp : Time;
  message : string;
}

