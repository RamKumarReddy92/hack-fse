import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Product } from '../model/product.model';
import { AuthService } from '../services/auth.service';
import { CustomerService } from '../services/customer.service';
import { ProductService } from '../services/product.service';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  products : Product[] = [
  //   {
  //   productName : "samsung",
  //   productId : 123,
  //   productDescription : "camera",
  //   features : "FLAGSHIP",
  //   productStatus : "AVAILABLE",
  //   quantity : 5,
  //   cost : 300000
  // },{
  //   productName : "samsung",
  //   productId : 123,
  //   productDescription : "camera",
  //   features : "FLAGSHIP",
  //   productStatus : "AVAILABLE",
  //   quantity : 5,
  //   cost : 300000
  // }
]
 
  constructor(private dialog : MatDialog,
    private productService : ProductService,
    private router : Router,
    private authService : AuthService,
    private customerService : CustomerService) { }

  ngOnInit(): void {
    this.productService.getAllProducts().subscribe(data=>{
      this.products = data;
    })

  }
  openDialog() {
    this.dialog.open(CartAddedDialog);
  }

  search  = new FormControl('');
  searchProducts()
  {
    this.productService.searchProducts(this.search.value)
    .subscribe((data:Product[])=>{
      this.products = data;
    })
  }

  addToCart(index:number)
  {
    if(!this.authService.loggedIn())
    {
      this.router.navigate(["/login"]);
      return;
    }
    this.openDialog();
    this.customerService.addToCart(this.products[index].productId).subscribe(data=>{
      console.log(data);
    })
    
  }


}

@Component({
  selector: 'cart-added-dialog',
  templateUrl: 'cart-added-dialog.html',
})
export class CartAddedDialog {}


