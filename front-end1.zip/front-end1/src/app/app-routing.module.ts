import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { AuthGuard } from './auth.guard';
import { CartComponent } from './cart/cart.component';
import { CustomerRegisterComponent } from './customer-register/customer-register.component';
import { LoginComponent } from './login/login.component';
import { ProductRegisterComponent } from './product-register/product-register.component';
import { ProductsComponent } from './products/products.component';
import { ProfileComponent } from './profile/profile.component';
import { OrdersComponent } from './orders/orders.component';

const routes: Routes = [{path:"customers/register",component:CustomerRegisterComponent},
                        {path:"login",component:LoginComponent} ,                      
                        {path:"products/register",component:ProductRegisterComponent},
                        {path:"customers/profile",component:ProfileComponent,canActivate:[AuthGuard]},
                        {path:"products",component:ProductsComponent},
                        {path:"admin",component:AdminComponent,canActivate:[AuthGuard]},
                        {path:"customers/cart",component:CartComponent,canActivate:[AuthGuard]},
                        {path:"customers/orders",component:OrdersComponent,canActivate:[AuthGuard]}
                       ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
