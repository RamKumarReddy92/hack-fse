import { Component, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { MatTable } from '@angular/material/table';
import { Product } from '../model/product.model';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(private customerService : CustomerService) { }

  @ViewChild('table',{static:true}) table : MatTable<any> = {} as MatTable<any>;

  products : Product[] = [];

  totalAmount : number = 0;

  count : number = 0;

  address : FormControl = new FormControl("");

  addAddress : boolean = false;

  displayedColumns = ["productName","features","cost","delete"]

  ngOnInit(): void {
    this.customerService.getCartItems().subscribe(data=>{
      this.products = data;
      this.count = this.products.length;
    for(let product of this.products)
      this.totalAmount += product.cost;
    });
 
  }

  delete(row : Product)
  {
    for(let i =0;i<this.products.length;i++)
     {
       if(this.products[i].productId===row.productId)
       {
         this.products.splice(i,1);
         this.table.renderRows();
         console.log(this.products);
         break;
       }
     }
     this.customerService.deleteCartItem(row.productId).subscribe(data=>{
       console.log(data);
     })
  }

  placeOrder(){}


}
