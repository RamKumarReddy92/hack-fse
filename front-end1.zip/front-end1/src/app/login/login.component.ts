import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userLogin : FormGroup = {} as FormGroup;
  constructor(private authService : AuthService,private fb : FormBuilder) { }

  loginSuccess : boolean = true;
  ngOnInit(): void {
    this.userLogin = this.fb.group({
      loginId: [
        '',
        [
          Validators.required
        ],
      ],
      password: ['', [Validators.required]],
    });
    this.authService.loggedIn$.subscribe(data=>this.loginSuccess=data);
  }

  onSubmit()
  {
    this.authService.login(this.userLogin.value);
  }


}
