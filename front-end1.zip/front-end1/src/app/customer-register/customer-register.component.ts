import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-customer-register',
  templateUrl: './customer-register.component.html',
  styleUrls: ['./customer-register.component.css']
})
export class CustomerRegisterComponent implements OnInit {

  constructor(private formBuilder : FormBuilder,private customerService : CustomerService) { }

  customerRegisterForm : FormGroup  = {} as FormGroup;
  ngOnInit(): void {
    this.customerRegisterForm = this.formBuilder.group({
      firstName : ['',Validators.required],
      lastName : ['',Validators.required],
      email : ['',Validators.required],
      loginId : ['',Validators.required],
      password : ['',Validators.required],
      confirmPassword : ['',Validators.required],
      contactNumber : ['',Validators.required]
    })
  }

  onSubmit()
  {
    console.log(this.customerRegisterForm.value);
    this.customerService.registerCustomer(this.customerRegisterForm.value);
  }

}
