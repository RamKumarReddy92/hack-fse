import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatTable } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { Product } from '../model/product.model';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private productService : ProductService,private dialog: MatDialog) { }

  @ViewChild('table',{static:true}) table : MatTable<any> = {} as MatTable<any>;
  products: Product[] = [] ;

  edit : boolean = false;
  displayedColumns: string[] = ['productName', 'quantity', 'productStatus', 'edit','delete'];
  ngOnInit(): void {
    this.productService.getAllProducts().subscribe(data=>{
      this.products = data;
    })

  }

  delete(row:Product)
  {
    console.log(row);
     for(let i =0;i<this.products.length;i++)
     {
       if(this.products[i].productId===row.productId)
       {
         this.products.splice(i,1);
         this.table.renderRows();
         console.log(this.products);
         break;
       }
     }
     this.productService.deleteProduct(row.productId).subscribe(data=>{
       console.log(data);
     })

  }

  editStatus(row:Product,status:string)
  {
    for(let i =0;i<this.products.length;i++)
     {
       if(this.products[i].productId===row.productId)
       {
         this.products[i].productStatus = status;
         this.table.renderRows();
         break;
       }
     }
     this.productService.updateProductStatus(row.productId,status).subscribe(data=>{
       console.log(data);
     })
  }


  openDialog(row:Product) {
    
    this.productService.statusUpdate$.subscribe(status=>{
      this.editStatus(row,status);
    }
    )
    this.dialog.open(ProductStatusUpdateDialog);
    
  }

}




@Component({
  selector: 'product-status-update',
  templateUrl: 'product-status-update.html',
})
export class ProductStatusUpdateDialog {

  constructor(private productService : ProductService){}
  status : FormControl = new FormControl("");
  updateStatus()
  {
      this.productService.statusUpdate$.next(this.status.value)
  }
}
