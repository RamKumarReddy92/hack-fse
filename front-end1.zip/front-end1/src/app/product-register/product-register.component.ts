import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-product-register',
  templateUrl: './product-register.component.html',
  styleUrls: ['./product-register.component.css']
})
export class ProductRegisterComponent implements OnInit {

  constructor(private fb : FormBuilder,private productService : ProductService) { }
  
  productRegisterForm : FormGroup  = {} as FormGroup;

  ngOnInit(): void {
    this.productRegisterForm = this.fb.group({
      productName : ['',Validators.required],
      productDescription : ['',Validators.required],
      features : ['',Validators.required],
      productStatus : ['',Validators.required],
      quantity : ['',Validators.required],
      cost : ['',Validators.required]
    })
  }

  onSubmit()
  {
    this.productService.addProduct(this.productRegisterForm.value);
    console.log(this.productRegisterForm.value);
  }

}
