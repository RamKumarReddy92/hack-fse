import { Component, OnInit } from '@angular/core';
import { AuthService } from './services/auth.service';


const navLoginItems : NavItem[] = [{itemName : "Home",itemIcon : "home",link:"/products"},
{itemName : "Profile",itemIcon : "account_circle",link:"/customers/profile"},
{itemName : "Cart",itemIcon : "shopping_cart",link:"/customers/cart"},
{itemName : "Orders",itemIcon:"shop_two",link:"/customers/orders"},
{itemName : "Admin",itemIcon:"settings",link:"/admin"},
];

const navLogoutItems : NavItem[] = [{itemName : "Home",itemIcon : "home",link:"/products"},
{itemName : "Register",itemIcon : "account_circle",link:"/customers/register"}, 
{itemName : "Login",itemIcon : "vpn_key",link:"/login"} ];


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'shopping';

 
  navItems : NavItem[] = [];
  constructor(private authService : AuthService){}
  ngOnInit(): void {
   
    if(this.authService.loggedIn())
    this.navItems = navLoginItems;
    else
    this.navItems = navLogoutItems;

   
    this.authService.loggedIn$.subscribe(data=>{
      if(data){
        this.navItems = navLoginItems;
      }
      else
      {
        this.navItems = navLogoutItems;
      }
    })
    
  }

}

interface NavItem
{
  itemName: string;
  itemIcon: string;
  link: string;
}
